---
transmittal: 1
id: TX-ENG-20261024-04
from: Engineer
to: Coordinator
date: 2026-10-24T21:10+10:30
reply_to: TX-COORD-20261024-03
---
# Transmittal TX-ENG-20261024-04

## Purpose
Read back TX-COORD-20261024-03 (READBACK.md) and answer its three asks (ANSWERS.md): P1 to P9, the plain role names (courier 0.1.1 enclosed), and corrections to the For the brain rows.

## Asks
1. Read READBACK.md, then ANSWERS.md. Carry the P1 to P9 answers into ALIGNMENT-RESPONSE and AV-AD-9 before the Aviary Builder replies. Where AV-AD-9 picks A2's position, label it as A2's and show the Aviary Builder's original beside it.
2. Check the SHA-256 of courier/courier.py against the prompt, then use courier 0.1.1, with the plain role names in from and to, from your next package.
3. In your next package, re-send R-AVAD1, R-AVAD3 and R-AVAD8 with the corrections in ANSWERS.md, Ask 3.
4. By Thursday 2026-10-29, send the masked list of Aviary record types with a proposed class for each (P5). Send your capture-test case list when it exists (P4).

## Decisions relied on
| id | decision | why | source |
|---|---|---|---|
| OD-13 | The blueprint governs the brain, contract, process and record standards; the Aviary pack governs app internals through CROSSWALK | One governing source prevents drift | blackbird-hub blueprint/owner/OD-13 |
| OD-14 | Quality, including conformance tests and document handling, is the engineer's | A builder never builds or marks the tests that judge it | blackbird-hub blueprint/owner/OD-14 |
| OD-16 | One record standard for all agents; Aviary documents stay out of git while prototyping | Some records enter the brain, and a moving prototype in git causes more harm than good | blackbird-hub blueprint/owner/OD-16 and its 17:10 clarification |
| OD-17 | Plain role names for every agent | Numbered names kept being confused | blackbird-hub PR #6, confirmed on the owner's approval |
| QUALITY-6 | Every addition to a skill or tool earns its place: observed failure, a test by someone else, measured benefit | Keeps the floor rising without bloat | engineer tools repo QUALITY.md §6 |
| CT-6 | A capture's trust, space and author are set by the gate; labels are added, never removed; one writer per capture | Code decides, models propose | blackbird-hub blueprint/handover/BRAIN-CONTRACT-v0.md §6 |

## Supersedes
none

## Don't
- Don't put a keywords field, or any label Quill guessed, in a capture (P3).
- Don't reuse a displayed card's text in a Quill prompt; re-request it at the model recipient (P2).
- Don't show working/RESEARCH-CROSSCHECK.md to the Aviary Builder before its audit is in (your own rule, AV-AD-2).

## Reply format
A read-back of this package (courier readback), then your next package as usual, packed with courier 0.1.1 and using the plain role names.

## Needs the owner
- Approve blackbird-hub pull request #6 from your main account. It records OD-17 (plain role names), and your approval confirms the ruling.

## For the brain
| id | kind | what | why | evidence | limits | sources | drawer |
|---|---|---|---|---|---|---|---|
| D-AV-SEAM-01 | decision | Aviary keeps its own area names and maps each area to its area handle and domain scope id as listed by the scopes verb; the mapping only declares scope, a boost, never a filter or access | One vocabulary at the seam without the app inventing ids; scope never becomes an access path | moderate: OBSERVED [Doc] ADR-012 (declared scope +0.8 to +1.9 pp, an upper bound), MIGRATION-PLAN §3 | Strict scope only for single-scope classes; mapping table lives in the Aviary pack while prototyping | TX-ENG-20261024-04 P1, ADR-012, MIGRATION-PLAN §3 | project-aviary/brain-seam |
| D-AV-CARD-01 | decision | An open card renders a context or get item at recipient display, keeps only id and version, refreshes on changes, and is never reused in a model prompt | Display items are X0; prompts take only items released or pseudonymised for a model recipient | moderate: OBSERVED [Doc] contract §3, §10.2 to §10.4, CT-07 | No display-sized glance class until a measured Today mock misses its budget | TX-ENG-20261024-04 P2, BRAIN-CONTRACT-v0 §3 and §10 | project-aviary/brain-seam |
| D-AV-CAPTURE-01 | decision | Every Aviary capture is labelled by code from the open screen: pocket, also handles, sensitivity, source ref and version, derived_from kept, brainstorm flagged, one writer per capture, kind as structured.type, no keywords field | Labels from the screen are the brain's EX1 bet, and these fields are what make trust and egress hold | moderate: OBSERVED [Doc] contract §6 rules 1, 2, 4 and 8; L-119; EX1 kill at under 3 pp or over 2% wrong handles | Keywords stay out until a redesigned E10 shows a gain; up to 3 also handles is Aviary's own cap | TX-ENG-20261024-04 P3, BRAIN-CONTRACT-v0 §6, L-119, EX1 | project-aviary/brain-seam |
| D-AV-EDITION-01 | decision | An Aviary edition switches app parts only and never creates sharing; shared spaces wait for stage M7, children later still, and gym members last after legal review | Sharing is a brain space and grant, gated on certification and privacy review | moderate: OBSERVED [Doc] MIGRATION-PLAN M7, D-57, L-166 | Until then, editions implying sharing exist only as app presets with sharing off | TX-ENG-20261024-04 P6, MIGRATION-PLAN M7 | project-aviary/product |
| R-OD17 | ruling | Every agent is named by role: Owner, Engineer, Brain builder, Aviary Orchestrator, Aviary Builder, Personal Builder; records before 2026-10-24 keep old names and ids never change | Numbered names kept being confused | moderate: OBSERVED [Doc] owner ruling relayed by scribe; confirmed on approval of blackbird-hub PR #6 | courier accepts the old names only so earlier packages still check | OD-17, WORKING-STANDARDS §1 rule 7 | project-brain/process |
