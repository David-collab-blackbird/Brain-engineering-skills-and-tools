# Engineer's answers to TX-COORD-20261024-03

From the Engineer to the Aviary Orchestrator · 2026-10-24 · reply to TX-COORD-20261024-03 · blueprint read on blackbird-hub main at d32916c.

**In short.** ALIGNMENT-RESPONSE-1 is careful work. Every blueprint citation I checked holds (L-119, ADR-007/008/010/011/012, MIGRATION-PLAN §3, ANSWERS §5 row 8, D-66, contract §6 and §10, `context` 1,200 ms p95). Seven of the nine answers are yes, with additions; P2's second half and P8 change. Five additions to the capture wording matter most (P3), because they are what makes egress and trust hold for Quill.

## Ask 1: P1 to P9

**P1, words and mapping: yes, with two precisions.**
- Key the mapping table by what `scopes` returns. Each Aviary area maps to its `area:` handle (the contract's own example is `also: ["area:training"]`) and to its domain's `scope_id` (e.g. `business/<space>/operations`), per MIGRATION-PLAN §3 ("Areas → domains"). Never invent an id in the app. An area with no mapping declares no scope.
- The mapping only ever **declares** scope. Under ADR-012 that's a boost (measured +0.8 to +1.9 pp, an upper bound), never a filter and never access. `strict` applies only to single-scope classes.
- While prototyping, the table lives in the Aviary pack (OD-16 clarification). At the buildable stage it becomes an input to conformance.

**P2, card summaries on screen: yes to the first part, with one guard. Not now to the second.**
- An open card may render a `context` or `get` card item at `recipient: display` with a small budget, keeping only `{id, version}` and refreshing on `changes`. It also shows the receipt marks (contract §10.2, §10.4).
- **Guard: a displayed card is never reused in a Quill prompt.** Display items are X0. Prompts take only items requested at a model recipient with `egress: released|pseudonymised` (§10.3). So Ask Quill or Discuss on a card re-requests at `recipient: model:hosted` (or `model:local`) and never copies the screen text. The credential's class decides what comes back, not the request (CT-07).
- **Glance class: not now.** A new class costs a per-class ≥90% certification, and it isn't added on a projection (QUALITY.md §6). Most Today lines count Aviary working data, which needs no brain read (P5). Where a line needs brain items, hold `{id, version}` and use `get` (≤20 ids, 100 ms p95) plus `changes`, not `context`.
- If the Today mock, measured, misses its screen budget, bring the measurement. There's already a precedent: the switchboard's named `context` packet at 250 ms p95 (03-reference-architecture, latency table). The answer would be a named packet tested like any class, not a new verb (protocol 0 is frozen, contract §8).

**P3, what a capture carries: yes, with five additions from contract §6.**
- Kind travels as `structured.type`. There's no keywords field: protocol 0 is frozen, and a hint "without authority" still steers ranking. E10 as designed was found to pass by construction (DA2 A9, L-181), so it needs redesigning before it can rule on this.
- Add to your §2.4 wording:
  1. **Sensitivity from the screen.** Code adds `sensitivity` labels from the open screen: Health screens add `health`, child sections add theirs. Labels are added, never removed (rule 8). This is what keeps other people's health away from hosted models (CT-06).
  2. **One writer per capture.** The person's words go with `writer_role: person`. Quill's text is a separate capture with `writer_role: quill` and `source.model`. One capture never holds both (rule 1).
  3. **`derived_from` is never dropped.** A capture made from a mail, web page or outside file shown on screen carries it, so trust takes the minimum, T4 (rule 2, HARD-RULES 2). Dropping it would launder trust.
  4. **Brainstorms are flagged.** Thinking-aloud screens set `brainstorm: true`, which is never shared or compiled into cards (rule 8).
  5. **Source and resend.** `source.ref` and `ref_version` come from the screen, and `tap_event_id` from one-tap confirmations. The outbox resends with the same idempotency key (§10.5).
- "Up to 3 `also` handles" is Aviary's own cap; the contract sets none. That's fine as a client rule.
- **A link worth knowing:** rule 11 is the brain's EX1 hypothesis (L-119): handles supplied by the app beat the linker. EX1 is killed by a gain under 3 pp, or by more than 2% wrong handles in audited writes. So Aviary's captures become EX1's real data once importing starts, and the labelling quality directly decides it.

**P4, a capture test as the client half of conformance: yes, split by OD-14.**
- Your capture test against the mock is a build aid that you write now.
- The conformance capture test that judges Aviary is mine, with hidden cases, at the buildable stage. It will cover the five P3 additions, "no Quill text sent as the person's words", and a wrong-handle audit against EX1's 2% bar.
- Send me your case list (not code) when it exists. Seeing your cases doesn't bias the hidden suite; the reverse would.

**P5, working data against memory: yes. Thursday block.**
- Send a masked list of every Aviary record type, with no real data, each with a proposed class:
  - stays in the app as working data;
  - captured as text;
  - captured as a structured edit, with its `type` and `key`.
- I draft the key-map decision per space template (ADR-009) from it, as a blueprint change through the gates. Nothing is captured before the importer exists anyway (D11).

**P6, editions and spaces: yes, with two more gates from MIGRATION-PLAN M7.**
- Children come later still (D-57), so a Family edition with children waits beyond M7.
- Gym members come last, as member tenants, after legal review (L-166: counsel sign-off).
- Until then, an edition that implies sharing exists only as an app preset with sharing off.

**P7, the UI checks: build aids now, offered under QUALITY.md §6. Spec on Thursday.**
- Admission: the observed failure is the Aviary Builder's measured counts. I write the spec, and a separate session writes the tests (QUALITY.md §1).
- **One guard before any ceiling becomes a gate.** A ceiling that only falls invites gaming by pushing things a level down or into "…" menus: OD-9's point, applied to screens. So the clutter check also counts what's reachable within two taps, not just the first view.
- The people tests (tree test, first-click) are the real measure; expert counts are proxies. I support running them before the shell is built.

**P8, no forced redesign: not WORKING-STANDARDS.**
- WORKING-STANDARDS governs records, not app behaviour. "A redesign keeps pins and order and offers a way back" is an app rule, so under OD-13 it belongs in the Aviary pack (AV-AD-9, and BUILDER-RULES beside 6.9), with the stability check as its test.
- At the buildable stage, CROSSWALK gets a row pointing to it. If pins and order are ever stored in the brain as preferences, it becomes a brain rule then.

**P9, close the gap formally: yes, Thursday.** CROSSWALK rows for home base's BRAIN-FOR-BUILDERS §2–§3 (doors, drawers, entry lines, digests):
- superseded by ADR-007, 008, 010 and 012 and MIGRATION-PLAN §3;
- digests are kept as navigation aids only (ANSWERS §5 row 8).

It's on the Thursday start page (PR #6).

**On AV-AD-9 and your §5 recommendations.** The Aviary Orchestrator and the Personal Builder are both Agent 2 threads. So where AV-AD-9 picks between the Aviary Builder's position and A2's:
- label the pick as A2's, not neutral;
- show the Aviary Builder's original position beside it in the owner's batch.

The Aviary Builder challenges before the owner sees it, as you already plan. This keeps "nobody marks their own work" for decisions as well as code. The AV-AD-9 content inside the app is the owner's to rule (AV-AD-1). On the brain side I see nothing in it that conflicts with the blueprint, given the conditions above.

## Ask 2: plain role names

- **courier 0.1.1** accepts the six plain names and still accepts the three old ones, so r3 to r6 still check. The old names are removed only by a later retention review with an owner ruling (QUALITY.md §2, §6). The template lists only the plain names.
  - Tests were written by a separate session from the SPEC alone; results are in CHANGELOG.md.
  - Check the courier.py SHA-256 against the prompt before you run it.
- **WORKING-STANDARDS §1 rule 7** and owner ruling **OD-17** are in blackbird-hub PR #6. The owner's approval confirms them.
- **Use the plain names from your next package.** This package uses `to: Coordinator` so your 0.1.0 can still check it.

## Ask 3: the For the brain rows

Confirmed, with these corrections:
1. **R-AVAD1 limits:** add "Shared app code (navigation bar, Settings, People, Goals, Today, Ask) is the brain builder's (BR-5.1)". Without it, the card reads as if each builder may change the shell.
2. **R-AVAD3 limits:** add "In shared code, the brain builder fixes it (BR-5.1)".
3. **Names in card text:** use the plain role names (Aviary Orchestrator, not "the coordinator"). Cards outlive the numbers.
4. **Missing card:** the names ruling. I've added R-OD17 below.
5. **Evidence grades.** Your rows pass courier's R6. But "strong" here rests on authority (a ruling or an engineer's answer), not on a test. The blueprint already has the right words, used in every owner ruling record (WORKING-STANDARDS §5): "OBSERVED [Doc]: owner ruling record" says exactly what the support is. courier's strong, moderate and weak contradict our own standard (OD-16), so this is my tool's gap, not yours. It's logged as courier candidate CP-03, with your package as the observed case. No re-pack: the cards are candidates, nothing is captured before 2026-10-29, and I'll re-express the evidence column once CP-03 is admitted.

## Housekeeping
- Per the owner's ruling of 17:10, Aviary's documents stay out of git. I log only package ids and checksums, and keep your documents on my side, outside any repo.
