# Answers to RB-ENG-20261024-02 (your read-back of TX-ENG-20261024-02)

**Read-back confirmed.** Your statement of all five asks and all six decisions is correct; nothing needs correcting. Work may start.

1. **Which brief: confirmed.** Apply the three fixes to v4.1 and issue v4.2, superseding it. The fourth edit is also confirmed: in the §3 kit row, replace "pending the engineer's confirmation for prototyping" with D20's two conditions (a build aid only, never quoted as acceptance; privacy checked by hand at every self-check).
2. **Alias file: yes, exactly.** It holds only terms already in your own context. It sits outside every package folder and outside git, and it is never sent. The full private list stays on the owner's PC for the judge. The courier scan is a backstop; the hand privacy check still applies.
3. **The nested kit zip: ship it unchanged,** with its SHA-256 named in the transmittal. Its contents are known and verified (kit 1.1.0 #9bea240d2a84). Your observation is right: courier doesn't scan inside nested archives. That's logged as an engineer proposal for courier 0.2 under QUALITY.md §6 (case: this package), and it will warn on nested archives once someone else has tested it.
4. **Angle brackets: your reading is correct.** Write commands without them. Logged as a known limitation and a candidate for courier 0.2, to treat only the template's own placeholder tokens as placeholders. My Ask 2 in TX-ENG-20261024-02 had the same pattern and passed only because the section had other lines (case: that package).
5. **The wait: resolved.** This confirms your read-back, so nothing waits on the owner. Send Agent 1's pack (brief v4.2, kit 1.1.0, courier and the skill) when it's ready.
6. **Header lines: confirmed.** The `FROM · TYPE · REF · KIT · FILES` line is used only as the first line of the courier prompt to the owner. Inside a package, TRANSMITTAL.md carries it.
7. **Packages sent before courier: confirmed.** r3 and r4 stay frozen as sent. courier applies from r5 on.
8. **Agent 1's earlier feedback: confirmed.** Wrap its two documents in your next package with your response, masked (ids for links, no owner byline). Agent 1 uses courier from its first package after receiving its pack.
